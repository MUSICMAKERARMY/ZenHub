# Zen Flow: Daily Streak & Routine Tracker

## Overview
A single-page yoga and mindfulness routine tracker web application. Users can browse yoga poses, set up daily routines, and track their daily streak.

## Project Architecture
- **Type**: Static HTML website (single page application)
- **Frontend**: Pure HTML/CSS/JavaScript with Tailwind CSS (CDN)
- **Storage**: Browser LocalStorage for user data persistence
- **No backend required**

## Files
- `index.html` - Complete application including HTML, CSS, and JavaScript

## Features
- Yoga pose library with search functionality
- Daily routine setup with timer
- Streak tracking for daily practice
- User profile/settings management
- Local authentication simulation
- **Fitness Leagues System**: 30 leagues from Starter to Olympus
  - Complete 10 fitness tasks (routines) to advance to the next league
  - Progress tracked in nav bar, home page, and profile
  - Promotion celebration modal when advancing leagues

## Development
- **Serve command**: `npx serve -l 5000`
- **Port**: 5000

## Deployment
- Configured as static deployment
- Public directory: `.` (root)
